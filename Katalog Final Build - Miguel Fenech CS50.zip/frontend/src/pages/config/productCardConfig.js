//All Products Page - Product Cards Column Selection

//Default Title Columns are Bolded
export const defaultTitleColumns = ['Brand', 'Description', 'Single Unit Measure', 'Unit of Measure'];

//Other Relevant Product information/properties to be displayed in product card.
export const defaultColumns = ['Item Code', 'Supplier Product Code'];
