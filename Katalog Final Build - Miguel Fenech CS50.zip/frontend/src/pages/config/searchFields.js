export const searchConfig = {
    fields:  ['Brand', 'Description', 'Supplier Product Code']
}